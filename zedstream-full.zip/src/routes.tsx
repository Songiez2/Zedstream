import type { ReactNode } from 'react';
import HomePage from './pages/HomePage';
import MusicPage from './pages/MusicPage';
import VideosPage from './pages/VideosPage';
import AwardsPage from './pages/AwardsPage';
import UploadPage from './pages/UploadPage';
import LibraryPage from './pages/LibraryPage';
import DashboardPage from './pages/DashboardPage';
import AdminPage from './pages/AdminPage';
import LoginPage from './pages/LoginPage';
import SearchPage from './pages/SearchPage';
import TrendingPage from './pages/TrendingPage';
import MyDownloadsPage from './pages/MyDownloadsPage';

export interface RouteConfig {
  name: string;
  path: string;
  element: ReactNode;
  visible?: boolean;
  public?: boolean;
}

export const routes: RouteConfig[] = [
  { name: 'Home',        path: '/',          element: <HomePage />,          public: true },
  { name: 'Music',       path: '/music',     element: <MusicPage />,         public: true },
  { name: 'Videos',      path: '/videos',    element: <VideosPage />,        public: true },
  { name: 'Awards',      path: '/awards',    element: <AwardsPage />,        public: true },
  { name: 'Trending',    path: '/trending',  element: <TrendingPage />,      public: true },
  { name: 'Search',      path: '/search',    element: <SearchPage />,        public: true },
  { name: 'Upload',      path: '/upload',    element: <UploadPage />,        public: false },
  { name: 'Library',     path: '/library',   element: <LibraryPage />,       public: false },
  { name: 'Downloads',   path: '/downloads', element: <MyDownloadsPage />,   public: false },
  { name: 'Dashboard',   path: '/dashboard', element: <DashboardPage />,     public: false },
  { name: 'Profile',     path: '/profile',   element: <DashboardPage />,     public: false },
  { name: 'Admin',       path: '/admin',     element: <AdminPage />,         public: false },
  { name: 'Login',       path: '/login',     element: <LoginPage />,         public: true },
];
