import { useEffect, useRef, useCallback, useState } from 'react';
import { Play, Pause, Volume2, VolumeX, Maximize, X, Video as VideoIcon } from 'lucide-react';
import { Button } from '@/components/ui/button';
import type { Video } from '@/types/index';
import { incrementViewCount } from '@/lib/api';
import { formatDuration } from '@/lib/utils';

interface VideoPlayerProps {
  video: Video;
  onClose?: () => void;
}

export default function VideoPlayer({ video, onClose }: VideoPlayerProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [playing, setPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [muted, setMuted] = useState(false);
  const [fullscreen, setFullscreen] = useState(false);
  const countedRef = useRef(false);

  useEffect(() => {
    const v = videoRef.current;
    if (!v) return;
    const onTime = () => {
      setCurrentTime(v.currentTime);
      if (v.currentTime >= 10 && !countedRef.current) {
        countedRef.current = true;
        incrementViewCount(video.id);
      }
    };
    const onLoad = () => setDuration(v.duration);
    const onEnded = () => setPlaying(false);
    v.addEventListener('timeupdate', onTime);
    v.addEventListener('loadedmetadata', onLoad);
    v.addEventListener('ended', onEnded);
    return () => {
      v.removeEventListener('timeupdate', onTime);
      v.removeEventListener('loadedmetadata', onLoad);
      v.removeEventListener('ended', onEnded);
    };
  }, [video.id]);

  const togglePlay = useCallback(() => {
    const v = videoRef.current;
    if (!v) return;
    if (playing) { v.pause(); setPlaying(false); }
    else { v.play().then(() => setPlaying(true)).catch(console.error); }
  }, [playing]);

  const seek = (e: React.ChangeEvent<HTMLInputElement>) => {
    const v = videoRef.current;
    if (!v) return;
    v.currentTime = Number(e.target.value);
    setCurrentTime(Number(e.target.value));
  };

  const toggleFullscreen = () => {
    const v = videoRef.current;
    if (!v) return;
    if (!document.fullscreenElement) { v.requestFullscreen(); setFullscreen(true); }
    else { document.exitFullscreen(); setFullscreen(false); }
  };

  return (
    <div className="fixed inset-0 z-[60] bg-black/95 flex items-center justify-center p-4">
      <div className="relative w-full max-w-4xl max-h-[calc(100%-2rem)]">
        {/* Close */}
        {onClose && (
          <Button
            variant="ghost"
            size="icon"
            className="absolute -top-10 right-0 text-white/80 hover:text-white z-10"
            onClick={onClose}
          >
            <X className="h-5 w-5" />
          </Button>
        )}

        {/* Video */}
        <div className="relative bg-black rounded-lg overflow-hidden">
          <video
            ref={videoRef}
            src={video.file_url}
            poster={video.thumbnail_url}
            className="w-full aspect-video"
            muted={muted}
            playsInline
            onClick={togglePlay}
          />

          {/* Center play/pause overlay */}
          {!playing && (
            <div
              className="absolute inset-0 flex items-center justify-center cursor-pointer"
              onClick={togglePlay}
            >
              <div className="w-16 h-16 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center">
                <Play className="h-8 w-8 text-white fill-white ml-1" />
              </div>
            </div>
          )}

          {/* Controls bar */}
          <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-3">
            {/* Progress */}
            <input
              type="range"
              min={0}
              max={duration || 100}
              step={0.5}
              value={currentTime}
              onChange={seek}
              className="progress-bar w-full mb-2"
            />
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Button variant="ghost" size="icon" className="h-7 w-7 text-white hover:bg-white/10" onClick={togglePlay}>
                  {playing ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4 fill-white" />}
                </Button>
                <Button variant="ghost" size="icon" className="h-7 w-7 text-white hover:bg-white/10" onClick={() => setMuted(m => !m)}>
                  {muted ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
                </Button>
                <span className="text-white/80 text-xs">{formatDuration(currentTime)} / {formatDuration(duration)}</span>
              </div>
              <Button variant="ghost" size="icon" className="h-7 w-7 text-white hover:bg-white/10" onClick={toggleFullscreen}>
                <Maximize className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>

        {/* Meta */}
        <div className="mt-3 text-white">
          <h2 className="text-base font-semibold">{video.title}</h2>
          <p className="text-sm text-white/60">{video.artist_name} · {video.view_count.toLocaleString()} views</p>
        </div>
      </div>
    </div>
  );
}
