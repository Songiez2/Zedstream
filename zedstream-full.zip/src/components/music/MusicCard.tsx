import { useState } from 'react';
import { Play, Pause, Heart, BookmarkPlus, Share2, Music, Download } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';
import type { Song } from '@/types/index';
import { useAuth } from '@/contexts/AuthContext';
import { toggleLike, toggleSave, recordDownload, incrementSongDownloadCount } from '@/lib/api';
import { formatDuration } from '@/lib/utils';
import ShareSheet from '@/components/common/ShareSheet';

interface MusicCardProps {
  song: Song;
  isPlaying?: boolean;
  onPlay?: (song: Song) => void;
  compact?: boolean;
}

export default function MusicCard({ song, isPlaying, onPlay, compact = false }: MusicCardProps) {
  const { user } = useAuth();
  const [liked, setLiked] = useState(song.liked ?? false);
  const [saved, setSaved] = useState(song.saved ?? false);
  const [downloading, setDownloading] = useState(false);
  const [shareOpen, setShareOpen] = useState(false);

  const shareUrl = `${window.location.origin}/music?id=${song.id}`;
  const shareText = `Listen to ${song.title} by ${song.artist_name} on ZedStream`;

  const handleLike = async (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!user) { toast.error('Sign in to like songs'); return; }
    try {
      const result = await toggleLike(user.id, song.id, 'song');
      setLiked(result);
      toast.success(result ? 'Added to liked' : 'Removed from liked');
    } catch { toast.error('Failed to update like'); }
  };

  const handleSave = async (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!user) { toast.error('Sign in to save songs'); return; }
    try {
      const result = await toggleSave(user.id, song.id, 'song');
      setSaved(result);
      toast.success(result ? 'Saved to library' : 'Removed from library');
    } catch { toast.error('Failed to update library'); }
  };

  const handleShare = (e: React.MouseEvent) => {
    e.stopPropagation();
    setShareOpen(true);
  };

  const handleDownload = async (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!user) { toast.error('Sign in to download songs'); return; }
    if (downloading) return;
    setDownloading(true);
    try {
      const a = document.createElement('a');
      a.href = song.file_url;
      a.download = `${song.title} - ${song.artist_name}.mp3`;
      a.target = '_blank';
      a.rel = 'noopener noreferrer';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      // Record after triggering download
      await Promise.all([
        incrementSongDownloadCount(song.id),
        recordDownload({
          user_id: user.id,
          content_id: song.id,
          content_type: 'song',
          file_url: song.file_url,
          title: song.title,
          artist_name: song.artist_name,
          cover_url: song.cover_url,
        }),
      ]);
      toast.success('Download started');
    } catch { toast.error('Download failed'); }
    finally { setDownloading(false); }
  };

  if (compact) {
    return (
      <div
        className={`flex items-center gap-3 p-2 rounded-lg cursor-pointer transition-colors group ${
          isPlaying ? 'bg-accent/10' : 'hover:bg-muted'
        }`}
        onClick={() => onPlay?.(song)}
      >
        <div className="relative h-10 w-10 rounded shrink-0 overflow-hidden bg-muted">
          {song.cover_url ? (
            <img src={song.cover_url} alt={song.title} className="w-full h-full object-cover" />
          ) : (
            <div className="w-full h-full flex items-center justify-center">
              <Music className="h-4 w-4 text-muted-foreground" />
            </div>
          )}
          <div className={`absolute inset-0 flex items-center justify-center bg-black/40 transition-opacity ${
            isPlaying ? 'opacity-100' : 'opacity-0 group-hover:opacity-100'
          }`}>
            {isPlaying ? <Pause className="h-3 w-3 text-white" /> : <Play className="h-3 w-3 text-white fill-white" />}
          </div>
        </div>
        <div className="flex-1 min-w-0">
          <p className={`text-sm font-medium truncate ${isPlaying ? 'text-accent' : ''}`}>{song.title}</p>
          <p className="text-xs text-muted-foreground truncate">{song.artist_name}</p>
        </div>
        <span className="text-xs text-muted-foreground shrink-0">{formatDuration(song.duration)}</span>
      </div>
    );
  }

  return (
    <div className="group relative bg-card border border-border rounded-lg overflow-hidden card-hover">
      {/* Cover */}
      <div className="relative aspect-square bg-muted overflow-hidden">
        {song.cover_url ? (
          <img src={song.cover_url} alt={song.title} className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105" />
        ) : (
          <div className="w-full h-full flex items-center justify-center bg-muted">
            <Music className="h-12 w-12 text-muted-foreground/40" />
          </div>
        )}
        {/* Play overlay */}
        <div
          className={`absolute inset-0 flex items-center justify-center bg-black/40 transition-opacity cursor-pointer ${
            isPlaying ? 'opacity-100' : 'opacity-0 group-hover:opacity-100'
          }`}
          onClick={() => onPlay?.(song)}
        >
          <div className={`w-12 h-12 rounded-full flex items-center justify-center ${isPlaying ? 'bg-accent' : 'bg-white/90'}`}>
            {isPlaying
              ? <Pause className="h-5 w-5 text-white" />
              : <Play className="h-5 w-5 text-foreground fill-foreground ml-0.5" />
            }
          </div>
        </div>
        {song.is_trending && (
          <span className="absolute top-2 left-2 bg-accent text-accent-foreground text-[10px] font-semibold px-2 py-0.5 rounded-full">
            Trending
          </span>
        )}
      </div>

      {/* Info */}
      <div className="p-3">
        <h3 className="font-semibold text-sm truncate mb-0.5">{song.title}</h3>
        <p className="text-xs text-muted-foreground truncate">{song.artist_name}</p>

        <div className="flex items-center justify-between mt-2 pt-2 border-t border-border">
          <span className="text-xs text-muted-foreground">{song.play_count.toLocaleString()} plays · {(song.download_count ?? 0).toLocaleString()} ↓</span>
          <div className="flex items-center gap-0.5">
            <Button variant="ghost" size="icon" className="h-7 w-7" onClick={handleLike}>
              <Heart className={`h-3.5 w-3.5 ${liked ? 'fill-destructive text-destructive' : ''}`} />
            </Button>
            <Button variant="ghost" size="icon" className="h-7 w-7" onClick={handleSave}>
              <BookmarkPlus className={`h-3.5 w-3.5 ${saved ? 'fill-accent text-accent' : ''}`} />
            </Button>
            <Button variant="ghost" size="icon" className="h-7 w-7" onClick={handleDownload} disabled={downloading}>
              <Download className={`h-3.5 w-3.5 ${downloading ? 'animate-pulse text-accent' : ''}`} />
            </Button>
            <Button variant="ghost" size="icon" className="h-7 w-7" onClick={handleShare}>
              <Share2 className="h-3.5 w-3.5" />
            </Button>
          </div>
        </div>
      </div>
      <ShareSheet
        open={shareOpen}
        onClose={() => setShareOpen(false)}
        url={shareUrl}
        title={song.title}
        text={shareText}
      />
    </div>
  );
}
