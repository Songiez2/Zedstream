import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Trophy, Users, Star } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import type { Award, Song, Video, Artist, Sponsor } from '@/types/index';
import {
  getTrendingSongs, getPopularSongs, getNewSongs,
  getTrendingVideos, getActiveAwards, getFeaturedArtists, getActiveSponsors
} from '@/lib/api';
import HeroSlider from '@/components/hero/HeroSlider';
import SectionRow from '@/components/common/SectionRow';
import MusicCard from '@/components/music/MusicCard';
import VideoCard from '@/components/video/VideoCard';
import VideoPlayer from '@/components/video/VideoPlayer';
import { usePlayer } from '@/contexts/PlayerContext';

export default function HomePage() {
  const [trendingSongs, setTrendingSongs] = useState<Song[]>([]);
  const [popularSongs, setPopularSongs] = useState<Song[]>([]);
  const [newSongs, setNewSongs] = useState<Song[]>([]);
  const [trendingVideos, setTrendingVideos] = useState<Video[]>([]);
  const [awards, setAwards] = useState<Award[]>([]);
  const [artists, setArtists] = useState<Artist[]>([]);
  const [sponsors, setSponsors] = useState<Sponsor[]>([]);
  const [loading, setLoading] = useState(true);
  const [currentVideo, setCurrentVideo] = useState<Video | null>(null);
  const { currentSong, playSong } = usePlayer();

  useEffect(() => {
    Promise.all([
      getTrendingSongs(8),
      getPopularSongs(8),
      getNewSongs(8),
      getTrendingVideos(8),
      getActiveAwards(),
      getFeaturedArtists(8),
      getActiveSponsors(),
    ]).then(([ts, ps, ns, tv, aw, ar, sp]) => {
      setTrendingSongs(ts);
      setPopularSongs(ps);
      setNewSongs(ns);
      setTrendingVideos(tv);
      setAwards(aw);
      setArtists(ar);
      setSponsors(sp);
    }).catch(console.error).finally(() => setLoading(false));
  }, []);

  return (
    <div className="min-h-screen pb-20 lg:pb-0">
      {/* Hero */}
      <div className="pt-0">
        <HeroSlider />
      </div>

      {/* Trending Now */}
      <SectionRow title="Trending Now" viewAllLink="/music" loading={loading} grid skeletonCount={6} skeletonClassName="aspect-square">
        {trendingSongs.map(song => (
          <MusicCard key={song.id} song={song} isPlaying={currentSong?.id === song.id} onPlay={s => playSong(s, trendingSongs)} />
        ))}
        {trendingVideos.slice(0, 4).map(video => (
          <VideoCard key={video.id} video={video} onPlay={setCurrentVideo} />
        ))}
      </SectionRow>

      <div className="border-t border-border" />

      {/* New Releases */}
      <SectionRow title="New Releases" viewAllLink="/music" loading={loading} grid skeletonCount={6} skeletonClassName="aspect-square">
        {newSongs.map(song => (
          <MusicCard key={song.id} song={song} isPlaying={currentSong?.id === song.id} onPlay={s => playSong(s, newSongs)} />
        ))}
      </SectionRow>

      <div className="border-t border-border" />

      {/* Popular Music */}
      <SectionRow title="Popular Music" viewAllLink="/music" loading={loading} grid skeletonCount={6} skeletonClassName="aspect-square">
        {popularSongs.map(song => (
          <MusicCard key={song.id} song={song} isPlaying={currentSong?.id === song.id} onPlay={s => playSong(s, popularSongs)} />
        ))}
      </SectionRow>

      <div className="border-t border-border" />

      {/* Trending Videos */}
      <SectionRow title="Trending Videos" viewAllLink="/videos" loading={loading} grid skeletonCount={4} skeletonClassName="aspect-video">
        {trendingVideos.map(video => (
          <VideoCard key={video.id} video={video} onPlay={setCurrentVideo} />
        ))}
      </SectionRow>

      <div className="border-t border-border" />

      {/* ZedStream Awards */}
      <section className="py-6">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-bold flex items-center gap-2">
              <Trophy className="h-5 w-5 text-accent" /> ZedStream Awards
            </h2>
            <Link to="/awards" className="text-xs text-muted-foreground hover:text-accent transition-colors font-medium">View all →</Link>
          </div>
          {loading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {[1, 2].map(i => <Skeleton key={i} className="h-32 rounded-lg" />)}
            </div>
          ) : awards.length === 0 ? (
            <div className="text-center py-12 text-muted-foreground">
              <Trophy className="h-10 w-10 mx-auto mb-3 opacity-30" />
              <p className="text-sm">No active awards at the moment.</p>
              <Link to="/awards" className="text-xs text-accent hover:underline mt-1 inline-block">Check back soon</Link>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
              {awards.map(award => (
                <Link key={award.id} to="/awards"
                  className="group block bg-card border border-border rounded-lg p-4 card-hover"
                >
                  <div className="flex items-start justify-between mb-2">
                    <h3 className="font-semibold text-sm group-hover:text-accent transition-colors">{award.name}</h3>
                    <Badge variant={award.voting_open ? 'default' : 'secondary'} className="text-[10px] shrink-0 ml-2">
                      {award.voting_open ? 'Voting Open' : 'Coming Soon'}
                    </Badge>
                  </div>
                  <p className="text-xs text-muted-foreground mb-3 line-clamp-2">{award.description || `${award.year} Awards`}</p>
                  <div className="flex items-center gap-3 text-xs text-muted-foreground">
                    <span className="flex items-center gap-1">
                      <Star className="h-3 w-3" />{award.award_categories?.length || 0} categories
                    </span>
                    <span className="flex items-center gap-1">
                      <Users className="h-3 w-3" />
                      {award.award_categories?.reduce((a, c) => a + (c.nominees?.length || 0), 0) || 0} nominees
                    </span>
                  </div>
                </Link>
              ))}
            </div>
          )}
        </div>
      </section>

      <div className="border-t border-border" />

      {/* Featured Artists */}
      <SectionRow title="Featured Artists" viewAllLink="/music" loading={loading} grid skeletonCount={6} skeletonClassName="aspect-square">
        {artists.map(artist => (
          <div key={artist.id} className="text-center group">
            <div className="h-20 w-20 md:h-28 md:w-28 rounded-full overflow-hidden mx-auto mb-2 bg-muted border-2 border-border group-hover:border-accent transition-colors">
              {artist.avatar_url
                ? <img src={artist.avatar_url} alt={artist.name} className="w-full h-full object-cover" />
                : <div className="w-full h-full flex items-center justify-center text-2xl font-bold text-muted-foreground/40">{artist.name[0]}</div>
              }
            </div>
            <p className="text-xs font-semibold truncate">{artist.name}</p>
            <p className="text-[10px] text-muted-foreground">{artist.play_count.toLocaleString()} plays</p>
          </div>
        ))}
      </SectionRow>

      {/* Sponsors */}
      {sponsors.length > 0 && (
        <>
          <div className="border-t border-border" />
          <section className="py-6">
            <div className="max-w-7xl mx-auto px-4">
              <h2 className="text-sm font-semibold text-muted-foreground text-center uppercase tracking-widest mb-4">Award Sponsors</h2>
              <div className="flex flex-wrap items-center justify-center gap-6">
                {sponsors.map(sponsor => (
                  <a key={sponsor.id} href={sponsor.website_url || '#'} target="_blank" rel="noopener noreferrer"
                    className="flex items-center gap-2 opacity-60 hover:opacity-100 transition-opacity"
                  >
                    {sponsor.logo_url
                      ? <img src={sponsor.logo_url} alt={sponsor.name} className="h-8 object-contain" />
                      : <span className="text-sm font-semibold text-muted-foreground">{sponsor.name}</span>
                    }
                  </a>
                ))}
              </div>
            </div>
          </section>
        </>
      )}

      {/* Music Player */}

      {/* Video Player modal */}
      {currentVideo && <VideoPlayer video={currentVideo} onClose={() => setCurrentVideo(null)} />}
    </div>
  );
}
