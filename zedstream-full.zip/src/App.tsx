import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import IntersectObserver from '@/components/common/IntersectObserver';
import ScrollToTop from '@/components/common/ScrollToTop';
import { Toaster } from '@/components/ui/sonner';
import { AuthProvider } from '@/contexts/AuthContext';
import { PlayerProvider } from '@/contexts/PlayerContext';
import { RouteGuard } from '@/components/common/RouteGuard';
import Header from '@/components/layout/Header';
import MobileNav from '@/components/layout/MobileNav';
import MusicPlayer from '@/components/music/MusicPlayer';
import AdminLayout from '@/components/admin/AdminLayout';
import AdminOverviewPage from '@/pages/admin/AdminOverviewPage';
import AdminUsersPage from '@/pages/admin/AdminUsersPage';
import AdminContentPage from '@/pages/admin/AdminContentPage';
import AdminPaymentsPage from '@/pages/admin/AdminPaymentsPage';
import AdminAwardsPage from '@/pages/admin/AdminAwardsPage';
import AdminSettingsPage from '@/pages/admin/AdminSettingsPage';
import AdminDownloadsPage from '@/pages/admin/AdminDownloadsPage';
import AdminNotificationsPage from '@/pages/admin/AdminNotificationsPage';
import { Navigate as NavRedirect } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { routes } from './routes';

// Guard for admin sub-routes
function AdminGuard({ children }: { children: React.ReactNode }) {
  const { profile, loading } = useAuth();
  if (loading) return null;
  if (!profile || (profile.role !== 'admin' && profile.role !== 'super_admin')) {
    return <NavRedirect to="/" replace />;
  }
  return <AdminLayout>{children}</AdminLayout>;
}

const App: React.FC = () => {
  return (
    <Router>
      <AuthProvider>
        <PlayerProvider>
        <RouteGuard>
          <ScrollToTop />
          <IntersectObserver />
          <Routes>
            {/* Admin sub-routes — full-screen layout, no Header/MobileNav */}
            <Route path="/admin" element={<AdminGuard><AdminOverviewPage /></AdminGuard>} />
            <Route path="/admin/content"       element={<AdminGuard><AdminContentPage /></AdminGuard>} />
            <Route path="/admin/videos"        element={<AdminGuard><AdminContentPage /></AdminGuard>} />
            <Route path="/admin/users"         element={<AdminGuard><AdminUsersPage /></AdminGuard>} />
            <Route path="/admin/payments"      element={<AdminGuard><AdminPaymentsPage /></AdminGuard>} />
            <Route path="/admin/awards"        element={<AdminGuard><AdminAwardsPage /></AdminGuard>} />
            <Route path="/admin/nominees"      element={<AdminGuard><AdminAwardsPage /></AdminGuard>} />
            <Route path="/admin/trending"      element={<AdminGuard><AdminAwardsPage /></AdminGuard>} />
            <Route path="/admin/downloads"     element={<AdminGuard><AdminDownloadsPage /></AdminGuard>} />
            <Route path="/admin/notifications" element={<AdminGuard><AdminNotificationsPage /></AdminGuard>} />
            <Route path="/admin/banners"       element={<AdminGuard><AdminSettingsPage /></AdminGuard>} />
            <Route path="/admin/settings"      element={<AdminGuard><AdminSettingsPage /></AdminGuard>} />

            {/* All other routes wrapped in the public layout */}
            <Route path="/*" element={
              <div className="flex flex-col min-h-screen">
                <Header />
                <main className="flex-grow">
                  <Routes>
                    {routes.filter(r => !r.path.startsWith('/admin')).map((route, index) => (
                      <Route key={index} path={route.path} element={route.element} />
                    ))}
                    <Route path="*" element={<Navigate to="/" replace />} />
                  </Routes>
                </main>
                {/* Player sits above mobile nav */}
                <MusicPlayer />
                <MobileNav />
              </div>
            } />
          </Routes>
          <Toaster richColors />
        </RouteGuard>
        </PlayerProvider>
      </AuthProvider>
    </Router>
  );
};

export default App;
